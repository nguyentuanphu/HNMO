# HNMO PR #455 · Automatic error reporting

Đối chiếu PR #455 tại `c809ac97e81b6ab9d22513e1083f2c95e8c26a83`, `integration/s9` tại `6bddf1bdd89b105752fbf8fb6ef5f2ae3326e238` và hnmobug tại `20e33e2dff95ac776690121a8ee6820941d382b9`. PR ở trạng thái draft, đang mở. Các phát hiện dựa trên source và fixture tổng hợp.

| Mức | Luồng | Phát hiện và thay đổi |
|---|---|---|
| P0 | Browser → GameServer → Admin Panel | Browser cũ giữ nội dung tự do trong fingerprint, message và stack. Server cắt độ dài rồi lưu và hiển thị. Bản vá chỉ giữ loại sự cố, tên tệp tĩnh cho phép, dòng và metadata thô được kiểm tra. Raw stack, text, GPU, map và tên nhân vật bị loại khỏi báo tự động. Nhóm không nhận diện được tệp được gộp theo loại. |
| P0 | GameServer → hnmobug | Weekly cũ đưa `kind:auto-error` vào `bugs`; `cleanBug()` đòi `text` nên bỏ nhóm, nhưng HTTP thành công vẫn đánh dấu nhóm đã gửi. Bản vá dùng mảng `autoErrors` riêng, tối đa 50, và chỉ đánh dấu theo ID trong `autoAccepted` sau khi ghi hub. Báo lỗi thủ công vẫn dùng schema cũ. |
| P1 | Quyền chuyển tiếp | Trang có policy Administrator. Bản vá kiểm tra lại policy ngay tại thao tác. Host duyệt một snapshot cố định trước khi đưa ra ngoài, bằng credential riêng theo machine. Gửi qua HTTPS hoặc loopback HTTP cho fixture. Client không nhận credential. Hub loại request auto-error sai credential trước thao tác ghi weekly. |
| P1 | Season và restart | `HnmoStateStore` tách tệp theo Season và dùng lock theo đường dẫn trong cùng tiến trình. Các GameServer trong một tiến trình dùng chung tệp chuẩn sẽ chia sẻ quota Sydney. Weekly chỉ chạy ở tiến trình chính. Bản vá dùng outbox theo Season trong thư mục save chung, chỉ chứa snapshot được duyệt. S6 chuyển các snapshot thay cho S9 mà không mở state nội bộ của S9. ACK lưu thành file biên nhận. |
| P1 | Ingress | C2 F5 60 yêu cầu phiên đăng nhập, giới hạn burst 5 rồi cấp 1 lượt mỗi 5 giây trước khi parse. Kiểm tra header, độ dài, JSON phẳng, trường trùng, kiểu dữ liệu, NUL và ngân sách 16 KiB. Ngưỡng mặc định 20/account và 1.000/Season/ngày Sydney. Cấu hình được chặn trên tại 100/account và 10.000/Season/ngày. |
| P1 | WebGL và disconnect | Bổ sung Playwright cho mất context qua `WEBGL_lose_context` và sự kiện đóng WebSocket thật do fixture kích hoạt. Disconnect chờ lần xác thực sau, cùng host/port/account trong cùng tab. (Web Crypto cần secure context hoặc loopback để khôi phục qua reload.) |
| P2 | Packet compatibility | XML C→S và S→C cùng bảng TS generated trên `integration/s9@6bddf1b` chưa có F5 60. PR dùng C2, code F5, subcode 60, JSON từ offset 5, không phản hồi. Parser nhận cả writer web không terminator và writer C# thêm một NUL. Cần overlay rồi chạy generator, build và test để xác nhận tương thích lúc chạy. |

Nguồn: [PR #455](https://github.com/nguyentuanphu/HNMO/pull/455) · [integration/s9](https://github.com/nguyentuanphu/HNMO/tree/6bddf1bdd89b105752fbf8fb6ef5f2ae3326e238) · [hnmobug](https://github.com/nguyentuanphu/hnmobug/tree/20e33e2dff95ac776690121a8ee6820941d382b9)

## Xác minh đã chạy

- Hai patch đạt `git diff --check` và `git apply --cached --check` trên các file gốc đã đối chiếu.
- 7/7 browser unit tests chạy trên module TS do Node chuyển sang JS, có fake storage.
- 29/29 hnmobug tests với memory store. Trong phiên này module Netlify được thay bằng stub lỗi nếu test cố gọi storage thật. Regression bao gồm credential sai, lưu Season 9, dữ liệu nhạy cảm tổng hợp, ACK và retry sau khi chuyển sang done.
- Đã viết C# tests cho parser, lọc dữ liệu, cập nhật đồng thời, tải lại tệp state, outbox theo Season và HTTP hub giả lập. Chưa chạy .NET hoặc Playwright in-game trong phiên này. Chưa build overlay S9.

## Điều kiện cần xác minh trước khi cân nhắc tích hợp

- Luồng outbox cần các tiến trình S6/S9 trên cùng host nhìn thấy cùng thư mục save gốc. Quota JSON áp dụng cho các GameServer dùng chung store trong cùng tiến trình. Nếu hạ tầng có nhiều tiến trình cùng ghi một Season hoặc nhiều host dùng chung quota, dùng PostgreSQL cho counters/groups và outbox transactional.
- Store cũ được lọc khi đọc lần đầu. Các bản sao lưu đã tồn tại có thể còn dữ liệu cũ. Cần xử lý retention của bản sao lưu và log cũ theo quyết định của host. Các nhóm legacy cần host duyệt lại vì trạng thái đã gửi trước đây có thể sai.
- Xác nhận deploy target dùng storage nhất quán khi Netlify nhận retry và khi workflow chuyển pending sang done. Test memory store xác minh luồng tuần tự, chưa xác minh đồng thời trên blob store thật.
- Kiểm tra e2e đóng socket từ bridge hoặc mất mạng và kiểm tra quyền với tài khoản anonymous, operator và administrator. Test Playwright hiện có đóng socket qua fixture client để kích hoạt đường xử lý close thực tế.
- Weekly hub giả lập phải dùng credential fixture. HNMO đọc `HNMO_AUTO_ERROR_FORWARD_KEY` và hnmobug đọc `AUTO_ERROR_FORWARD_KEYS`, JSON ánh xạ machine ID sang key. Dùng ASCII dạng base64url 32–256 ký tự. Chưa cấu hình credential thật.
